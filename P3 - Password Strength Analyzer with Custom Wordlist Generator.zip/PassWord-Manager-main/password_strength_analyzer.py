#!/usr/bin/env python3
"""
Password Strength Analyzer with Custom Wordlist Generator

Analyzes password strength using zxcvbn and custom entropy calculations,
and generates attack-specific wordlists from user-provided personal data.
"""

import argparse
import math
import os
import string
import sys
from itertools import product

try:
    import zxcvbn as zxcvbn_lib
    ZXCVBN_AVAILABLE = True
except ImportError:
    ZXCVBN_AVAILABLE = False

# ---------------------------------------------------------------------------
# Password Strength Analysis
# ---------------------------------------------------------------------------

SCORE_LABELS = {
    0: "Very Weak",
    1: "Weak",
    2: "Fair",
    3: "Strong",
    4: "Very Strong",
}

SCORE_COLORS = {
    0: "\033[91m",  # red
    1: "\033[91m",  # red
    2: "\033[93m",  # yellow
    3: "\033[92m",  # green
    4: "\033[92m",  # green
}
RESET = "\033[0m"

# Leet-speak substitution map (char → list of substitutions)
DEFAULT_YEAR_START = 2000
DEFAULT_YEAR_END = 2025

LEET_MAP = {
    "a": ["@", "4"],
    "b": ["8"],
    "e": ["3"],
    "g": ["9"],
    "i": ["1", "!"],
    "l": ["1"],
    "o": ["0"],
    "s": ["$", "5"],
    "t": ["7"],
    "z": ["2"],
}


def calculate_entropy(password: str) -> float:
    """Calculate Shannon entropy of a password based on character-set size."""
    charset_size = 0
    if any(c.islower() for c in password):
        charset_size += 26
    if any(c.isupper() for c in password):
        charset_size += 26
    if any(c.isdigit() for c in password):
        charset_size += 10
    special = set(string.punctuation)
    if any(c in special for c in password):
        charset_size += 32
    if charset_size == 0:
        return 0.0
    return len(password) * math.log2(charset_size)


def detect_patterns(password: str) -> list:
    """Return a list of human-readable pattern warnings found in the password."""
    warnings = []
    lower = password.lower()

    # Keyboard walks
    walks = ["qwerty", "asdf", "zxcv", "qwer", "asdfgh", "123456", "654321"]
    for walk in walks:
        if walk in lower:
            warnings.append(f"Contains keyboard pattern '{walk}'")

    # Repeated characters
    for i in range(len(password) - 2):
        if password[i] == password[i + 1] == password[i + 2]:
            warnings.append(f"Contains repeated character '{password[i]}'")
            break

    # Sequential digits
    digits = "0123456789"
    for i in range(len(password) - 2):
        pos = digits.find(password[i])
        if pos != -1 and pos + 2 < len(digits):
            if password[i + 1] == digits[pos + 1] and password[i + 2] == digits[pos + 2]:
                warnings.append("Contains sequential digits")
                break

    # Common year pattern
    import re
    if re.search(r"(19|20)\d{2}", password):
        warnings.append("Contains a year pattern (e.g. 2023)")

    # All same case / all digits
    if password.isdigit():
        warnings.append("Password is numeric only")
    if password.isalpha() and (password.islower() or password.isupper()):
        warnings.append("Password contains only letters in one case")

    return warnings


def analyze_password(password: str) -> dict:
    """
    Analyze password strength.

    Returns a dict with:
        score (0-4), label, entropy, crack_times, feedback, patterns
    """
    entropy = calculate_entropy(password)
    patterns = detect_patterns(password)

    result = {
        "password": password,
        "length": len(password),
        "entropy": entropy,
        "patterns": patterns,
    }

    if ZXCVBN_AVAILABLE:
        zx = zxcvbn_lib.zxcvbn(password)
        result["score"] = zx["score"]
        result["label"] = SCORE_LABELS[zx["score"]]
        result["crack_times"] = zx["crack_times_display"]
        result["feedback"] = zx["feedback"]
        result["guesses_log10"] = zx["guesses_log10"]
    else:
        # Fallback scoring based on entropy
        if entropy < 28:
            score = 0
        elif entropy < 36:
            score = 1
        elif entropy < 50:
            score = 2
        elif entropy < 64:
            score = 3
        else:
            score = 4
        result["score"] = score
        result["label"] = SCORE_LABELS[score]
        result["crack_times"] = {}
        result["feedback"] = {"warning": "", "suggestions": []}
        result["guesses_log10"] = None

    return result


def print_analysis(result: dict, color: bool = True) -> None:
    """Pretty-print password analysis results to stdout."""
    score = result["score"]
    col = SCORE_COLORS.get(score, "") if color else ""
    rst = RESET if color else ""

    print("\n" + "=" * 50)
    print("  PASSWORD STRENGTH ANALYSIS")
    print("=" * 50)
    print(f"  Password  : {'*' * len(result['password'])}")
    print(f"  Length    : {result['length']} characters")
    print(f"  Entropy   : {result['entropy']:.1f} bits")
    if result.get("guesses_log10") is not None:
        print(f"  Guesses   : 10^{result['guesses_log10']:.1f}")
    print(f"  Strength  : {col}{result['label']}{rst} ({score}/4)")

    crack = result.get("crack_times", {})
    if crack:
        print("\n  Estimated crack times:")
        labels = {
            "online_throttling_100_per_hour": "  Online (throttled, 100/hr)",
            "online_no_throttling_10_per_second": "  Online (10/sec)",
            "offline_slow_hashing_1e4_per_second": "  Offline slow hash (10k/sec)",
            "offline_fast_hashing_1e10_per_second": "  Offline fast hash (10B/sec)",
        }
        for key, label in labels.items():
            if key in crack:
                print(f"    {label:40s}: {crack[key]}")

    feedback = result.get("feedback", {})
    warning = feedback.get("warning", "")
    suggestions = feedback.get("suggestions", [])
    if warning:
        print(f"\n  ⚠  Warning : {warning}")
    if suggestions:
        print("  💡 Suggestions:")
        for s in suggestions:
            print(f"      • {s}")

    patterns = result.get("patterns", [])
    if patterns:
        print("  🔍 Detected patterns:")
        for p in patterns:
            print(f"      • {p}")

    print("=" * 50 + "\n")


# ---------------------------------------------------------------------------
# Wordlist Generator
# ---------------------------------------------------------------------------

COMMON_SUFFIXES = [
    "", "1", "12", "123", "1234", "12345", "!", "!!", "@", "#", "!1", "@1",
    "1!", "2!", "69", "00", "01", "99",
]

COMMON_PREFIXES = ["", "The", "the", "My", "my"]


def _leet_variants(word: str) -> list:
    """Generate all leet-speak variants of *word* (exponential in matches)."""
    word_lower = word.lower()
    positions = []  # (index, [substitutions])
    for i, ch in enumerate(word_lower):
        if ch in LEET_MAP:
            positions.append((i, LEET_MAP[ch]))

    # Cap: generate at most 64 variants to avoid explosion
    variants = set()
    variants.add(word)
    variants.add(word.lower())
    variants.add(word.upper())
    variants.add(word.capitalize())

    if not positions:
        return list(variants)

    # Only combine up to 3 positions to keep output manageable
    for r in range(1, min(len(positions), 3) + 1):
        from itertools import combinations
        for combo in combinations(positions, r):
            chars = list(word_lower)
            # For each combination pick first substitution
            for idx, subs in combo:
                chars[idx] = subs[0]
            leet_word = "".join(chars)
            variants.add(leet_word)
            variants.add(leet_word.capitalize())
            if len(variants) > 200:
                break
        if len(variants) > 200:
            break

    return list(variants)


def _year_variants(word: str, start_year: int = 1970, end_year: int = 2025) -> list:
    """Append years and common number suffixes to word."""
    variants = []
    for year in range(start_year, end_year + 1):
        variants.append(f"{word}{year}")
        variants.append(f"{word}{str(year)[2:]}")  # short year e.g. 23
    return variants


def generate_wordlist(user_data: dict, year_start: int = DEFAULT_YEAR_START, year_end: int = DEFAULT_YEAR_END) -> list:
    """
    Generate a custom wordlist from *user_data*.

    Expected keys (all optional):
        name, surname, username, dob (YYYY-MM-DD or DD/MM/YYYY),
        pet, city, company, keyword1, keyword2
    """
    base_tokens = []

    for key in ("name", "surname", "username", "pet", "city", "company", "keyword1", "keyword2"):
        val = user_data.get(key, "").strip()
        if val:
            base_tokens.append(val)

    # Parse date of birth
    dob = user_data.get("dob", "").strip()
    date_tokens = []
    if dob:
        import re
        numbers = re.findall(r"\d+", dob)
        date_tokens.extend(numbers)
        if len(numbers) >= 3:
            y, m, d = numbers[0], numbers[1], numbers[2]
            if len(y) == 4:
                date_tokens += [y, y[2:], m, d, m + d, d + m, m + d + y, d + m + y]
            else:
                # Assume DD/MM/YYYY or MM/DD/YYYY
                date_tokens += [numbers[-1], numbers[-1][2:], m, d]

    wordlist = set()

    # Single tokens with leet + case variants
    for token in base_tokens:
        for variant in _leet_variants(token):
            wordlist.add(variant)
            for suf in COMMON_SUFFIXES:
                wordlist.add(variant + suf)

    # Append year variants
    for token in base_tokens:
        for variant in _year_variants(token, year_start, year_end):
            wordlist.add(variant)
            leet_vars = _leet_variants(variant)
            wordlist.update(leet_vars[:10])  # limit

    # Combine pairs of base tokens
    if len(base_tokens) >= 2:
        for i in range(len(base_tokens)):
            for j in range(len(base_tokens)):
                if i != j:
                    combo = base_tokens[i] + base_tokens[j]
                    wordlist.add(combo)
                    wordlist.add(combo.capitalize())
                    for suf in COMMON_SUFFIXES[:8]:
                        wordlist.add(combo + suf)

    # Incorporate date tokens
    for dt in date_tokens:
        wordlist.add(dt)
        for token in base_tokens:
            wordlist.add(token + dt)
            wordlist.add(dt + token)
            wordlist.add(token.lower() + dt)
            wordlist.add(token.capitalize() + dt)

    # Common prefixes × base tokens
    for prefix in COMMON_PREFIXES:
        for token in base_tokens:
            if prefix:
                wordlist.add(prefix + token)
                wordlist.add(prefix + token.capitalize())

    # Remove empty strings
    wordlist.discard("")

    return sorted(wordlist)


def export_wordlist(words: list, filename: str) -> int:
    """Write *words* to *filename* (one per line). Returns word count."""
    with open(filename, "w", encoding="utf-8") as fh:
        for word in words:
            fh.write(word + "\n")
    return len(words)


# ---------------------------------------------------------------------------
# CLI helpers
# ---------------------------------------------------------------------------

def collect_user_data_interactive() -> dict:
    """Prompt the user for personal data in interactive mode."""
    print("\n--- Enter personal information (press Enter to skip any field) ---")
    fields = [
        ("name", "First name"),
        ("surname", "Last name / Surname"),
        ("username", "Username / Nickname"),
        ("dob", "Date of birth (e.g. 1990-05-20)"),
        ("pet", "Pet name"),
        ("city", "City / hometown"),
        ("company", "Company / school name"),
        ("keyword1", "Additional keyword 1"),
        ("keyword2", "Additional keyword 2"),
    ]
    data = {}
    for key, label in fields:
        val = input(f"  {label}: ").strip()
        if val:
            data[key] = val
    return data


# ---------------------------------------------------------------------------
# GUI (tkinter)
# ---------------------------------------------------------------------------

def launch_gui() -> None:
    """Launch the tkinter GUI."""
    try:
        import tkinter as tk
        from tkinter import ttk, messagebox, filedialog, scrolledtext
    except ImportError:
        print("tkinter is not available. Please install it or use the CLI interface.")
        sys.exit(1)

    root = tk.Tk()
    root.title("Password Strength Analyzer & Wordlist Generator")
    root.resizable(True, True)
    root.minsize(680, 500)

    style = ttk.Style(root)
    style.theme_use("clam")

    notebook = ttk.Notebook(root)
    notebook.pack(fill="both", expand=True, padx=10, pady=10)

    # ---- Tab 1: Analyze ----
    tab_analyze = ttk.Frame(notebook, padding=15)
    notebook.add(tab_analyze, text="  Analyze Password  ")

    ttk.Label(tab_analyze, text="Enter password to analyze:", font=("Helvetica", 11)).grid(
        row=0, column=0, sticky="w", pady=(0, 5)
    )

    pw_var = tk.StringVar()
    show_var = tk.BooleanVar(value=False)

    pw_frame = ttk.Frame(tab_analyze)
    pw_frame.grid(row=1, column=0, sticky="ew", pady=(0, 10))
    tab_analyze.columnconfigure(0, weight=1)
    pw_frame.columnconfigure(0, weight=1)

    pw_entry = ttk.Entry(pw_frame, textvariable=pw_var, show="*", font=("Courier", 12), width=40)
    pw_entry.grid(row=0, column=0, sticky="ew")

    def toggle_show():
        pw_entry.config(show="" if show_var.get() else "*")

    ttk.Checkbutton(pw_frame, text="Show", variable=show_var, command=toggle_show).grid(
        row=0, column=1, padx=(8, 0)
    )

    # Strength meter (colored label)
    strength_var = tk.StringVar(value="")
    strength_label = ttk.Label(tab_analyze, textvariable=strength_var, font=("Helvetica", 12, "bold"))
    strength_label.grid(row=2, column=0, sticky="w", pady=(0, 6))

    result_text = scrolledtext.ScrolledText(
        tab_analyze, height=16, state="disabled", font=("Courier", 10), wrap="word"
    )
    result_text.grid(row=3, column=0, sticky="nsew", pady=(0, 10))
    tab_analyze.rowconfigure(3, weight=1)

    score_colors_tk = {0: "#e74c3c", 1: "#e74c3c", 2: "#f39c12", 3: "#27ae60", 4: "#27ae60"}

    def do_analyze():
        pw = pw_var.get()
        if not pw:
            messagebox.showwarning("Input required", "Please enter a password.")
            return
        res = analyze_password(pw)
        score = res["score"]
        strength_var.set(f"Strength: {res['label']}  ({score}/4)")
        strength_label.config(foreground=score_colors_tk.get(score, "black"))

        lines = []
        lines.append(f"Length    : {res['length']} characters")
        lines.append(f"Entropy   : {res['entropy']:.1f} bits")
        if res.get("guesses_log10") is not None:
            lines.append(f"Guesses   : 10^{res['guesses_log10']:.1f}")
        crack = res.get("crack_times", {})
        if crack:
            lines.append("\nEstimated crack times:")
            crack_labels = {
                "online_throttling_100_per_hour": "  Online throttled (100/hr)",
                "online_no_throttling_10_per_second": "  Online (10/sec)",
                "offline_slow_hashing_1e4_per_second": "  Offline slow (10k/sec)",
                "offline_fast_hashing_1e10_per_second": "  Offline fast (10B/sec)",
            }
            for k, lbl in crack_labels.items():
                if k in crack:
                    lines.append(f"    {lbl:40s}: {crack[k]}")
        feedback = res.get("feedback", {})
        if feedback.get("warning"):
            lines.append(f"\nWarning: {feedback['warning']}")
        if feedback.get("suggestions"):
            lines.append("Suggestions:")
            for s in feedback["suggestions"]:
                lines.append(f"  • {s}")
        patterns = res.get("patterns", [])
        if patterns:
            lines.append("\nDetected patterns:")
            for p in patterns:
                lines.append(f"  • {p}")

        result_text.config(state="normal")
        result_text.delete("1.0", "end")
        result_text.insert("end", "\n".join(lines))
        result_text.config(state="disabled")

    ttk.Button(tab_analyze, text="Analyze", command=do_analyze).grid(
        row=4, column=0, pady=(0, 5)
    )

    # live update as user types
    def on_pw_change(*_):
        pw = pw_var.get()
        if not pw:
            strength_var.set("")
            return
        res = analyze_password(pw)
        score = res["score"]
        strength_var.set(f"Strength: {res['label']}  ({score}/4)")
        strength_label.config(foreground=score_colors_tk.get(score, "black"))

    pw_var.trace_add("write", on_pw_change)

    # ---- Tab 2: Generate Wordlist ----
    tab_gen = ttk.Frame(notebook, padding=15)
    notebook.add(tab_gen, text="  Generate Wordlist  ")

    fields_gui = [
        ("name", "First name"),
        ("surname", "Last name / Surname"),
        ("username", "Username / Nickname"),
        ("dob", "Date of birth (YYYY-MM-DD)"),
        ("pet", "Pet name"),
        ("city", "City / hometown"),
        ("company", "Company / school"),
        ("keyword1", "Keyword 1"),
        ("keyword2", "Keyword 2"),
    ]

    entries_gui = {}
    for row_idx, (key, label) in enumerate(fields_gui):
        ttk.Label(tab_gen, text=label + ":").grid(row=row_idx, column=0, sticky="w", padx=(0, 10))
        var = tk.StringVar()
        ttk.Entry(tab_gen, textvariable=var, width=30).grid(row=row_idx, column=1, sticky="ew")
        entries_gui[key] = var
    tab_gen.columnconfigure(1, weight=1)

    year_frame = ttk.LabelFrame(tab_gen, text="Year range", padding=8)
    year_frame.grid(
        row=len(fields_gui), column=0, columnspan=2, sticky="ew", pady=(12, 0)
    )
    ttk.Label(year_frame, text="From:").grid(row=0, column=0)
    year_start_var = tk.IntVar(value=DEFAULT_YEAR_START)
    ttk.Spinbox(year_frame, from_=1950, to=2025, textvariable=year_start_var, width=6).grid(
        row=0, column=1, padx=4
    )
    ttk.Label(year_frame, text="To:").grid(row=0, column=2, padx=(10, 0))
    year_end_var = tk.IntVar(value=DEFAULT_YEAR_END)
    ttk.Spinbox(year_frame, from_=1950, to=2025, textvariable=year_end_var, width=6).grid(
        row=0, column=3, padx=4
    )

    status_gen_var = tk.StringVar(value="")
    ttk.Label(tab_gen, textvariable=status_gen_var, foreground="#2980b9").grid(
        row=len(fields_gui) + 2, column=0, columnspan=2, pady=(8, 0)
    )

    def do_generate():
        user_data = {k: v.get().strip() for k, v in entries_gui.items()}
        if not any(user_data.values()):
            messagebox.showwarning("Input required", "Please fill in at least one field.")
            return
        try:
            ys = int(year_start_var.get())
            ye = int(year_end_var.get())
        except ValueError:
            ys, ye = 2000, 2025
        words = generate_wordlist(user_data, year_start=ys, year_end=ye)
        filepath = filedialog.asksaveasfilename(
            defaultextension=".txt",
            filetypes=[("Text files", "*.txt"), ("All files", "*.*")],
            title="Save Wordlist",
        )
        if filepath:
            count = export_wordlist(words, filepath)
            status_gen_var.set(f"✔ Exported {count} words to {os.path.basename(filepath)}")
            messagebox.showinfo("Done", f"Exported {count} words to:\n{filepath}")

    ttk.Button(
        tab_gen, text="Generate & Export Wordlist", command=do_generate
    ).grid(row=len(fields_gui) + 1, column=0, columnspan=2, pady=(12, 0))

    root.mainloop()


# ---------------------------------------------------------------------------
# CLI entry point
# ---------------------------------------------------------------------------

def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="password_strength_analyzer",
        description=(
            "Password Strength Analyzer & Custom Wordlist Generator.\n"
            "Analyze password strength and generate targeted attack wordlists."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  Analyze a password:
    python password_strength_analyzer.py analyze -p "MyP@ss2023"

  Generate wordlist interactively and export:
    python password_strength_analyzer.py generate --interactive -o wordlist.txt

  Generate wordlist from command-line args:
    python password_strength_analyzer.py generate --name Alice --pet Fluffy \\
        --dob 1990-05-20 --city London -o alice_wordlist.txt

  Launch the graphical interface:
    python password_strength_analyzer.py --gui
""",
    )

    parser.add_argument("--gui", action="store_true", help="Launch the graphical (tkinter) interface")
    parser.add_argument("--no-color", action="store_true", help="Disable colored output")

    subparsers = parser.add_subparsers(dest="command")

    # --- analyze ---
    analyze_parser = subparsers.add_parser("analyze", help="Analyze password strength")
    analyze_parser.add_argument("-p", "--password", help="Password to analyze")

    # --- generate ---
    gen_parser = subparsers.add_parser("generate", help="Generate a custom wordlist")
    gen_parser.add_argument("--interactive", "-i", action="store_true",
                            help="Prompt for personal data interactively")
    gen_parser.add_argument("--name", help="First name")
    gen_parser.add_argument("--surname", help="Last name / surname")
    gen_parser.add_argument("--username", help="Username / nickname")
    gen_parser.add_argument("--dob", help="Date of birth (YYYY-MM-DD or DD/MM/YYYY)")
    gen_parser.add_argument("--pet", help="Pet name")
    gen_parser.add_argument("--city", help="City or hometown")
    gen_parser.add_argument("--company", help="Company or school name")
    gen_parser.add_argument("--keyword1", help="Additional keyword 1")
    gen_parser.add_argument("--keyword2", help="Additional keyword 2")
    gen_parser.add_argument("--year-start", type=int, default=DEFAULT_YEAR_START, metavar="YEAR",
                            help=f"First year to append (default: {DEFAULT_YEAR_START})")
    gen_parser.add_argument("--year-end", type=int, default=DEFAULT_YEAR_END, metavar="YEAR",
                            help=f"Last year to append (default: {DEFAULT_YEAR_END})")
    gen_parser.add_argument("-o", "--output", default="wordlist.txt",
                            help="Output .txt filename (default: wordlist.txt)")

    return parser


def cmd_analyze(args, use_color: bool) -> None:
    password = args.password
    if not password:
        import getpass
        password = getpass.getpass("Enter password to analyze: ")
    result = analyze_password(password)
    print_analysis(result, color=use_color)


def cmd_generate(args) -> None:
    if args.interactive:
        user_data = collect_user_data_interactive()
    else:
        user_data = {
            "name": args.name or "",
            "surname": args.surname or "",
            "username": args.username or "",
            "dob": args.dob or "",
            "pet": args.pet or "",
            "city": args.city or "",
            "company": args.company or "",
            "keyword1": args.keyword1 or "",
            "keyword2": args.keyword2 or "",
        }
        if not any(user_data.values()):
            print("No personal data supplied. Use --interactive or provide flags like --name.")
            print("Run with --help for usage examples.")
            sys.exit(1)

    print(f"\nGenerating wordlist (year range {args.year_start}–{args.year_end})…")
    words = generate_wordlist(user_data, year_start=args.year_start, year_end=args.year_end)
    count = export_wordlist(words, args.output)
    print(f"✔ Exported {count} words to '{args.output}'")
    # Show a short preview
    preview = words[:10]
    print(f"\nPreview (first {len(preview)} words):")
    for w in preview:
        print(f"  {w}")
    if count > 10:
        print(f"  … and {count - 10} more")


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()

    if args.gui:
        launch_gui()
        return

    use_color = not args.no_color and sys.stdout.isatty()

    if args.command == "analyze":
        cmd_analyze(args, use_color)
    elif args.command == "generate":
        cmd_generate(args)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
