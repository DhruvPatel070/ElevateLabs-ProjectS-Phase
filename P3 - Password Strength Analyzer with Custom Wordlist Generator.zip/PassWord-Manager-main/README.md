# Password Strength Analyzer & Custom Wordlist Generator

A Python tool to **analyze password strength** and **generate attack-specific custom wordlists** from personal data.

---

## Features

- **Password strength analysis** using [zxcvbn](https://github.com/dwolfhub/zxcvbn-python) plus custom entropy/pattern detection
- **Pattern detection**: keyboard walks, sequential digits, repeated characters, year patterns
- **Custom wordlist generation** from user-supplied data (name, surname, date of birth, pet, city, company, keywords)
- **Leet-speak transformations** (`a→@/4`, `e→3`, `i→1/!`, `o→0`, `s→$`, `t→7`, …)
- **Year/number appending** (configurable year range, common suffixes like `!`, `123`, etc.)
- **Token combinations** (e.g. `AliceFluffy`, `Fluffy2023`, `@lice!`)
- **Export to `.txt`** format (compatible with Hashcat, John the Ripper, etc.)
- **CLI interface** via `argparse`
- **GUI interface** via `tkinter`

---

## Requirements

```
zxcvbn>=4.4.28
nltk>=3.8
```

Install with:

```bash
pip install -r requirements.txt
```

---

## Usage

### Command-Line Interface

#### Analyze a password

```bash
python password_strength_analyzer.py analyze -p "MyP@ss2023"
```

You can omit `-p` to be prompted securely (no echo):

```bash
python password_strength_analyzer.py analyze
```

#### Generate a wordlist (command-line arguments)

```bash
python password_strength_analyzer.py generate \
    --name Alice \
    --surname Smith \
    --pet Fluffy \
    --dob 1990-05-20 \
    --city London \
    --year-start 2015 \
    --year-end 2025 \
    -o alice_wordlist.txt
```

#### Generate a wordlist (interactive prompts)

```bash
python password_strength_analyzer.py generate --interactive -o wordlist.txt
```

#### Launch the GUI

```bash
python password_strength_analyzer.py --gui
```

---

### GUI Interface

The GUI provides two tabs:

| Tab | Description |
|-----|-------------|
| **Analyze Password** | Type a password and see live strength updates, crack-time estimates, and improvement tips |
| **Generate Wordlist** | Fill in personal data fields, choose a year range, and export the wordlist |

---

## Example Output

### Password Analysis (CLI)

```
==================================================
  PASSWORD STRENGTH ANALYSIS
==================================================
  Password  : ********
  Length    : 8 characters
  Entropy   : 52.4 bits
  Guesses   : 10^1.2
  Strength  : Very Weak (0/4)

  Estimated crack times:
    Online (throttled, 100/hr)              : 10 minutes
    Online (10/sec)                         : 2 seconds
    Offline slow hash (10k/sec)             : less than a second
    Offline fast hash (10B/sec)             : less than a second

  ⚠  Warning : This is similar to a commonly used password.
  💡 Suggestions:
      • Add another word or two. Uncommon words are better.
      • Predictable substitutions like '@' instead of 'a' don't help very much.
==================================================
```

### Wordlist Preview

```
@lice
@lice!
@lice2023
Alice
Alice!
Alice2020
Alice2021
AliceFluffy
AliceSmith
Fluffy@lice
fl00ffy
fluffy123
...
```

---

## Deployment

### Option 1 — Run directly (no install)

The simplest way to use the tool on any machine that has Python 3.9+:

```bash
# 1. Clone the repo
git clone https://github.com/Dhruv-6903/PassWord-Manager.git
cd PassWord-Manager

# 2. Install dependencies
pip install -r requirements.txt

# 3. Run
python password_strength_analyzer.py analyze -p "MyP@ss2023"
python password_strength_analyzer.py --gui
```

---

### Option 2 — Install as a system command (`pip install .`)

`pyproject.toml` turns the tool into a proper Python package and registers a
`password-analyzer` command that works from anywhere on your system.

```bash
# From inside the cloned repo:
pip install .

# Now available globally:
password-analyzer analyze -p "Hunter2!"
password-analyzer generate --name Alice --pet Fluffy -o wordlist.txt
password-analyzer --gui
```

To uninstall:

```bash
pip uninstall password-strength-analyzer
```

> **Tip — use `pipx` to keep dependencies isolated:**
>
> ```bash
> pipx install .
> ```

---

### Option 3 — Docker (CLI, no GUI)

Requires [Docker](https://docs.docker.com/get-docker/) to be installed.

**Build the image:**

```bash
docker build -t password-analyzer .
```

**Analyze a password:**

```bash
docker run --rm password-analyzer analyze -p "MyP@ss2023"
```

**Generate a wordlist and save it to your current directory:**

```bash
docker run --rm -v "$PWD":/data password-analyzer generate \
    --name Alice --surname Smith --pet Fluffy \
    --dob 1990-05-20 --city London \
    --year-start 2015 --year-end 2025 \
    -o /data/wordlist.txt
```

> The `-v "$PWD":/data` flag mounts your current directory inside the container
> so the exported `wordlist.txt` appears in your working folder.

---

### Option 4 — Standalone executable (PyInstaller)

Creates a single binary file that runs without Python installed — ideal for
sharing with people who don't have a Python environment.

```bash
# Install PyInstaller
pip install pyinstaller

# Build (CLI only; GUI requires a display)
pyinstaller --onefile --name password-analyzer password_strength_analyzer.py

# The executable is created at dist/password-analyzer
./dist/password-analyzer analyze -p "MyP@ss2023"
```

> On Windows the binary will be `dist\password-analyzer.exe`.

---

### Platform notes

| Platform | CLI | GUI |
|----------|-----|-----|
| Linux (desktop) | ✅ | ✅ |
| macOS | ✅ | ✅ |
| Windows | ✅ | ✅ |
| Linux (headless / Docker / CI) | ✅ | ❌ (no display) |

The GUI (`--gui`) requires a graphical display. On headless servers use the CLI
or Docker instead.

---

## Running Tests

```bash
python -m pytest test_password_analyzer.py -v
```

---

## Files

| File | Description |
|------|-------------|
| `password_strength_analyzer.py` | Main tool (analysis + wordlist generator + CLI + GUI) |
| `pyproject.toml` | Package metadata & `password-analyzer` CLI entry point |
| `requirements.txt` | Python dependencies |
| `Dockerfile` | Container image for CLI deployment |
| `.dockerignore` | Files excluded from the Docker build context |
| `test_password_analyzer.py` | Unit tests |
