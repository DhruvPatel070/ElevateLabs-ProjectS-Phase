"""
Tests for password_strength_analyzer.py
"""

import math
import os
import sys
import tempfile
import unittest

# Ensure the module can be imported from the repo root
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from password_strength_analyzer import (
    analyze_password,
    calculate_entropy,
    detect_patterns,
    export_wordlist,
    generate_wordlist,
)


class TestCalculateEntropy(unittest.TestCase):
    def test_lowercase_only(self):
        # 'abc' → charset=26, len=3
        entropy = calculate_entropy("abc")
        self.assertAlmostEqual(entropy, 3 * math.log2(26), places=5)

    def test_mixed_charset(self):
        # Should be larger than lowercase-only
        entropy_lower = calculate_entropy("abcdef")
        entropy_mixed = calculate_entropy("aBcDeF")
        self.assertGreater(entropy_mixed, entropy_lower)

    def test_with_digits_and_special(self):
        entropy = calculate_entropy("P@ssw0rd!")
        # charset = 26+26+10+32 = 94, len = 9
        expected = 9 * math.log2(94)
        self.assertAlmostEqual(entropy, expected, places=5)

    def test_empty_password(self):
        self.assertEqual(calculate_entropy(""), 0.0)

    def test_digits_only(self):
        entropy = calculate_entropy("123456")
        expected = 6 * math.log2(10)
        self.assertAlmostEqual(entropy, expected, places=5)


class TestDetectPatterns(unittest.TestCase):
    def test_keyboard_walk(self):
        patterns = detect_patterns("qwerty123")
        self.assertTrue(any("qwerty" in p for p in patterns))

    def test_sequential_digits(self):
        patterns = detect_patterns("abc123def")
        self.assertTrue(any("sequential" in p.lower() for p in patterns))

    def test_year_pattern(self):
        patterns = detect_patterns("pass2023")
        self.assertTrue(any("year" in p.lower() for p in patterns))

    def test_repeated_chars(self):
        patterns = detect_patterns("aaabcd")
        self.assertTrue(any("repeated" in p.lower() for p in patterns))

    def test_no_patterns_strong(self):
        patterns = detect_patterns("xK#9mPqZ")
        # Should not detect qwerty/sequential/year/repeated in a random string
        pattern_text = " ".join(patterns).lower()
        self.assertNotIn("qwerty", pattern_text)
        self.assertNotIn("year", pattern_text)

    def test_numeric_only(self):
        patterns = detect_patterns("123456789")
        self.assertTrue(any("numeric" in p.lower() for p in patterns))


class TestAnalyzePassword(unittest.TestCase):
    def test_returns_required_keys(self):
        result = analyze_password("TestPass1!")
        for key in ("score", "label", "entropy", "patterns", "length"):
            self.assertIn(key, result)

    def test_score_range(self):
        result = analyze_password("weak")
        self.assertIn(result["score"], range(5))

    def test_strong_password_high_score(self):
        result = analyze_password("CorrectHorseBatteryStaple!2$")
        self.assertGreaterEqual(result["score"], 3)

    def test_very_weak_password(self):
        result = analyze_password("password")
        self.assertLessEqual(result["score"], 1)

    def test_entropy_positive(self):
        result = analyze_password("Hello123!")
        self.assertGreater(result["entropy"], 0)

    def test_length_correct(self):
        pw = "abcde12345"
        result = analyze_password(pw)
        self.assertEqual(result["length"], len(pw))


class TestGenerateWordlist(unittest.TestCase):
    def setUp(self):
        self.user_data = {
            "name": "Alice",
            "pet": "Fluffy",
            "dob": "1990-05-20",
            "city": "London",
        }

    def test_returns_list(self):
        words = generate_wordlist(self.user_data, year_start=2020, year_end=2021)
        self.assertIsInstance(words, list)

    def test_not_empty(self):
        words = generate_wordlist(self.user_data, year_start=2020, year_end=2021)
        self.assertGreater(len(words), 0)

    def test_base_token_present(self):
        words = generate_wordlist(self.user_data, year_start=2020, year_end=2021)
        self.assertIn("Alice", words)

    def test_leet_variant_present(self):
        words = generate_wordlist(self.user_data, year_start=2020, year_end=2021)
        # @lice is a leet variant of Alice (a→@)
        self.assertIn("@lice", words)

    def test_year_appended(self):
        words = generate_wordlist(self.user_data, year_start=2020, year_end=2020)
        self.assertIn("Alice2020", words)

    def test_date_token_included(self):
        words = generate_wordlist(self.user_data, year_start=2020, year_end=2020)
        # '1990' should appear from DOB
        self.assertIn("1990", words)

    def test_no_empty_strings(self):
        words = generate_wordlist(self.user_data, year_start=2020, year_end=2020)
        self.assertNotIn("", words)

    def test_sorted_output(self):
        words = generate_wordlist(self.user_data, year_start=2020, year_end=2020)
        self.assertEqual(words, sorted(words))

    def test_empty_user_data(self):
        words = generate_wordlist({}, year_start=2020, year_end=2020)
        self.assertEqual(words, [])

    def test_combination_of_tokens(self):
        words = generate_wordlist(self.user_data, year_start=2020, year_end=2020)
        # Combination like 'AliceFluffy' or 'FluffyAlice' should appear
        has_combo = any("Alice" in w and "Fluffy" in w for w in words)
        self.assertTrue(has_combo)


class TestExportWordlist(unittest.TestCase):
    def test_export_creates_file(self):
        words = ["hello", "world", "test123"]
        with tempfile.NamedTemporaryFile(suffix=".txt", delete=False) as fh:
            path = fh.name
        try:
            count = export_wordlist(words, path)
            self.assertTrue(os.path.exists(path))
            self.assertEqual(count, 3)
        finally:
            os.unlink(path)

    def test_export_content(self):
        words = ["alpha", "beta", "gamma"]
        with tempfile.NamedTemporaryFile(
            suffix=".txt", delete=False, mode="w"
        ) as fh:
            path = fh.name
        try:
            export_wordlist(words, path)
            with open(path, "r") as fh:
                lines = [line.rstrip("\n") for line in fh.readlines()]
            self.assertEqual(lines, words)
        finally:
            os.unlink(path)

    def test_export_returns_count(self):
        words = ["a", "b", "c", "d", "e"]
        with tempfile.NamedTemporaryFile(suffix=".txt", delete=False) as fh:
            path = fh.name
        try:
            count = export_wordlist(words, path)
            self.assertEqual(count, 5)
        finally:
            os.unlink(path)


if __name__ == "__main__":
    unittest.main()
