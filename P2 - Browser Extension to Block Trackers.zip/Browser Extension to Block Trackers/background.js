/**
 * Privacy Shield - Background Service Worker
 */

importScripts("utils/tracker-list.js");

// ── State ─────────────────────────────────────────────────────────────────────
const blockedCounts  = {};  // tabId -> number
const blockedDetails = {};  // tabId -> [{domain, category, time}]

let globalStats = {
  totalBlocked:      0,
  categoryBreakdown: { analytics: 0, advertising: 0, social: 0, fingerprinting: 0, cryptomining: 0, other: 0 },
  dailyBlocked:      {},   // "YYYY-MM-DD" -> count
  topTrackers:       {}    // domain -> count
};

// Load persisted stats whenever service worker starts
(async function bootstrap() {
  const data = await chrome.storage.local.get(["globalStats"]);
  if (data.globalStats) globalStats = data.globalStats;
})();

// ── Install ───────────────────────────────────────────────────────────────────
chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.get(["whitelist","blacklist","extensionEnabled","globalStats"], (data) => {
    const defaults = {};
    if (!data.whitelist)        defaults.whitelist        = [];
    if (!data.blacklist)        defaults.blacklist        = [];
    if (data.extensionEnabled === undefined) defaults.extensionEnabled = true;
    if (!data.globalStats)      defaults.globalStats      = globalStats;
    chrome.storage.local.set(defaults);
  });
  updateDynamicRules();
});

// ── Rule-match debug listener ─────────────────────────────────────────────────
if (chrome.declarativeNetRequest.onRuleMatchedDebug) {
  chrome.declarativeNetRequest.onRuleMatchedDebug.addListener((info) => {
    const { tabId, request } = info;
    if (tabId >= 0) handleBlockedRequest(tabId, request.url);
  });
}

// ── Message handler ───────────────────────────────────────────────────────────
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  switch (msg.type) {
    case "TRACKER_DETECTED": {
      const tabId = sender.tab ? sender.tab.id : -1;
      if (tabId >= 0) handleBlockedRequest(tabId, msg.url);
      sendResponse({ ok: true });
      break;
    }
    case "GET_TAB_STATS": {
      const tabId = msg.tabId;
      sendResponse({
        count:   blockedCounts[tabId]  || 0,
        details: blockedDetails[tabId] || []
      });
      break;
    }
    case "GET_GLOBAL_STATS": {
      chrome.storage.local.get("globalStats", (data) => {
        sendResponse(data.globalStats || globalStats);
      });
      return true;
    }
    case "RESET_STATS": {
      globalStats = {
        totalBlocked:      0,
        categoryBreakdown: { analytics: 0, advertising: 0, social: 0, fingerprinting: 0, cryptomining: 0, other: 0 },
        dailyBlocked:      {},
        topTrackers:       {}
      };
      Object.keys(blockedCounts).forEach(k  => delete blockedCounts[k]);
      Object.keys(blockedDetails).forEach(k => delete blockedDetails[k]);
      chrome.storage.local.set({ globalStats });
      sendResponse({ ok: true });
      break;
    }
    case "CHECK_AUTH": {
      chrome.storage.local.get("jwtToken", (data) => {
        sendResponse({ authenticated: !!data.jwtToken });
      });
      return true;
    }
    case "GET_WHITELIST": {
      chrome.storage.local.get("whitelist", (data) => {
        sendResponse({ whitelist: data.whitelist || [] });
      });
      return true;
    }
    case "UPDATE_WHITELIST": {
      chrome.storage.local.set({ whitelist: msg.whitelist }, () => {
        updateDynamicRules();
        sendResponse({ ok: true });
      });
      return true;
    }
    case "GET_BLACKLIST": {
      chrome.storage.local.get("blacklist", (data) => {
        sendResponse({ blacklist: data.blacklist || [] });
      });
      return true;
    }
    case "UPDATE_BLACKLIST": {
      chrome.storage.local.set({ blacklist: msg.blacklist }, () => {
        updateDynamicRules();
        sendResponse({ ok: true });
      });
      return true;
    }
    case "TOGGLE_EXTENSION": {
      const enable = !!msg.enabled;
      chrome.storage.local.set({ extensionEnabled: enable });
      if (enable) {
        chrome.declarativeNetRequest.updateEnabledRulesets(
          { enableRulesetIds: ["tracker_rules"], disableRulesetIds: [] },
          () => sendResponse({ ok: true })
        );
      } else {
        chrome.declarativeNetRequest.updateEnabledRulesets(
          { enableRulesetIds: [], disableRulesetIds: ["tracker_rules"] },
          () => sendResponse({ ok: true })
        );
      }
      return true;
    }
  }
});

// ── Tab cleanup ───────────────────────────────────────────────────────────────
chrome.tabs.onRemoved.addListener((tabId) => {
  delete blockedCounts[tabId];
  delete blockedDetails[tabId];
});

// ── Reset per-tab counts on navigation ────────────────────────────────────────
chrome.webNavigation.onBeforeNavigate.addListener((details) => {
  if (details.frameId === 0) {
    blockedCounts[details.tabId]  = 0;
    blockedDetails[details.tabId] = [];
    updateBadge(details.tabId);
  }
});

// ── Helpers ───────────────────────────────────────────────────────────────────

function extractDomain(url) {
  try {
    return new URL(url).hostname.replace(/^www\./, "");
  } catch (_) {
    return "";
  }
}

let _saveTimer = 0;

function handleBlockedRequest(tabId, url) {
  const domain   = extractDomain(url);
  const category = getCategoryForDomain(domain) || "other";
  const now      = new Date();
  const dateKey  = now.toISOString().slice(0, 10);

  // Per-tab counts
  blockedCounts[tabId]  = (blockedCounts[tabId]  || 0) + 1;
  blockedDetails[tabId] = blockedDetails[tabId]   || [];
  blockedDetails[tabId].unshift({ domain, category, time: now.toISOString() });
  if (blockedDetails[tabId].length > 50) blockedDetails[tabId].pop();

  // Global stats
  globalStats.totalBlocked += 1;
  globalStats.categoryBreakdown[category] = (globalStats.categoryBreakdown[category] || 0) + 1;
  globalStats.dailyBlocked[dateKey]       = (globalStats.dailyBlocked[dateKey]       || 0) + 1;
  globalStats.topTrackers[domain]         = (globalStats.topTrackers[domain]         || 0) + 1;

  updateBadge(tabId);

  // // Persist every 10 blocks
  // _saveTimer++;
  // if (_saveTimer >= 10) {
  //   _saveTimer = 0;
  //   chrome.storage.local.set({ globalStats });
  // }

// Persist every block (reliable even if service worker sleeps)
  chrome.storage.local.set({ globalStats });

}

function updateBadge(tabId) {
  const count = blockedCounts[tabId] || 0;
  chrome.action.setBadgeText({ text: count > 0 ? String(count) : "", tabId });
  chrome.action.setBadgeBackgroundColor({ color: "#e74c3c", tabId });
}

function updateDynamicRules() {
  chrome.storage.local.get(["whitelist","blacklist"], (data) => {
    const whitelist = data.whitelist || [];
    const blacklist = data.blacklist || [];

    // Remove all existing dynamic rules first
    chrome.declarativeNetRequest.getDynamicRules((existing) => {
      const removeIds = existing.map((r) => r.id);
      const addRules  = [];
      let   ruleId    = 10000;

      // Whitelist → allow rules (higher priority = 2)
      whitelist.forEach((domain) => {
        addRules.push({
          id:        ruleId++,
          priority:  2,
          action:    { type: "allow" },
          condition: { urlFilter: "||" + domain, resourceTypes: ["script","xmlhttprequest","image","sub_frame"] }
        });
      });

      // Blacklist → block rules (priority 1)
      blacklist.forEach((domain) => {
        addRules.push({
          id:        ruleId++,
          priority:  1,
          action:    { type: "block" },
          condition: { urlFilter: "||" + domain, resourceTypes: ["script","xmlhttprequest","image","sub_frame"] }
        });
      });

      chrome.declarativeNetRequest.updateDynamicRules({ removeRuleIds: removeIds, addRules });
    });
  });
}
