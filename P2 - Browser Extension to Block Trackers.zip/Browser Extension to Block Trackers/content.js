/**
 * Privacy Shield - Content Script
 * Monitors dynamically injected scripts/iframes and reports trackers.
 */
(function () {
  "use strict";

  const TRACKER_PATTERNS = [
    /google-analytics\.com/i,
    /googletagmanager\.com/i,
    /hotjar\.com/i,
    /mixpanel\.com/i,
    /doubleclick\.net/i,
    /facebook\.net/i,
    /connect\.facebook\.net/i,
    /criteo\.com/i,
    /adnxs\.com/i,
    /taboola\.com/i,
    /outbrain\.com/i,
    /amplitude\.com/i,
    /segment\.(com|io)/i,
    /clarity\.ms/i,
    /scorecardresearch\.com/i,
    /googlesyndication\.com/i,
    /rubiconproject\.com/i,
    /pubmatic\.com/i,
    /fullstory\.com/i,
    /heapanalytics\.com/i,
    /quantserve\.com/i,
    /coinhive\.com/i,
    /coin-hive\.com/i,
    /fingerprintjs\.com/i
  ];

  function checkAndReport(url) {
    if (!url) return;
    for (const pattern of TRACKER_PATTERNS) {
      if (pattern.test(url)) {
        chrome.runtime.sendMessage({ type: "TRACKER_DETECTED", url });
        break;
      }
    }
  }

  // Watch for dynamically added <script> and <iframe> elements
  const observer = new MutationObserver((mutations) => {
    for (const mutation of mutations) {
      for (const node of mutation.addedNodes) {
        if (node.nodeType !== Node.ELEMENT_NODE) continue;
        if (node.tagName === "SCRIPT" && node.src)   checkAndReport(node.src);
        if (node.tagName === "IFRAME" && node.src)   checkAndReport(node.src);
        // Also check descendants
        node.querySelectorAll && node.querySelectorAll("script[src], iframe[src]").forEach((el) => {
          checkAndReport(el.src);
        });
      }
    }
  });

  observer.observe(document.documentElement, { childList: true, subtree: true });

  // Check scripts/iframes already in the DOM
  document.addEventListener("DOMContentLoaded", () => {
    document.querySelectorAll("script[src], iframe[src]").forEach((el) => {
      checkAndReport(el.src);
    });
  });
})();
