/**
 * Privacy Shield - JWT Authentication Utility
 * Client-side JWT implementation for the browser extension.
 *
 * Security note: The SECRET_KEY is stored in extension source files and is
 * therefore not truly secret. This implementation is intended for local
 * session management only and is NOT a substitute for server-side auth.
 * Passwords are hashed using SHA-256 via the Web Crypto API with a per-user
 * salt before being persisted in chrome.storage.local.
 */

const JWTAuth = {
  SECRET_KEY: "privacy-shield-secret-2024",

  base64UrlEncode(str) {
    // Encode UTF-8 string to Base64URL without deprecated escape()
    return btoa(encodeURIComponent(str).replace(/%([0-9A-F]{2})/g, (_, p1) =>
      String.fromCharCode(parseInt(p1, 16))
    ))
      .replace(/\+/g, "-")
      .replace(/\//g, "_")
      .replace(/=+$/, "");
  },

  base64UrlDecode(str) {
    str = str.replace(/-/g, "+").replace(/_/g, "/");
    while (str.length % 4) str += "=";
    // Decode Base64 to UTF-8 without deprecated unescape()
    return decodeURIComponent(
      atob(str).split("").map((c) =>
        "%" + ("00" + c.charCodeAt(0).toString(16)).slice(-2)
      ).join("")
    );
  },

  /**
   * SHA-256 password hash using Web Crypto API.
   * Returns a hex string. Accepts an optional salt string.
   * @param {string} str
   * @param {string} [salt]
   * @returns {Promise<string>}
   */
  async hashPassword(str, salt = "") {
    const encoder = new TextEncoder();
    const data    = encoder.encode(salt + str);
    const hashBuf = await crypto.subtle.digest("SHA-256", data);
    return Array.from(new Uint8Array(hashBuf))
      .map((b) => b.toString(16).padStart(2, "0"))
      .join("");
  },

  /**
   * Generate a random hex salt.
   * @returns {string}
   */
  generateSalt() {
    const arr = new Uint8Array(16);
    crypto.getRandomValues(arr);
    return Array.from(arr).map((b) => b.toString(16).padStart(2, "0")).join("");
  },

  sign(payload) {
    const header  = this.base64UrlEncode(JSON.stringify({ alg: "HS256", typ: "JWT" }));
    const body    = this.base64UrlEncode(JSON.stringify(payload));
    // Use a simple deterministic signing approach since this is client-side only
    const sigData = header + "." + body + "." + this.SECRET_KEY;
    let hash = 5381;
    for (let i = 0; i < sigData.length; i++) {
      hash = ((hash << 5) + hash) ^ sigData.charCodeAt(i);
      hash = hash & hash;
    }
    const sig = Math.abs(hash).toString(16);
    return `${header}.${body}.${sig}`;
  },

  verify(token) {
    try {
      const parts = token.split(".");
      if (parts.length !== 3) return null;
      const [header, body, sig] = parts;
      // Inline signature computation (matches sign())
      const sigData = header + "." + body + "." + this.SECRET_KEY;
      let hash = 5381;
      for (let i = 0; i < sigData.length; i++) {
        hash = ((hash << 5) + hash) ^ sigData.charCodeAt(i);
        hash = hash & hash;
      }
      const expectedSig = Math.abs(hash).toString(16);
      if (sig !== expectedSig) return null;
      const payload = JSON.parse(this.base64UrlDecode(body));
      if (payload.exp && Date.now() / 1000 > payload.exp) return null;
      return payload;
    } catch (_) {
      return null;
    }
  },

  generateToken(username) {
    const now = Math.floor(Date.now() / 1000);
    return this.sign({ sub: username, iat: now, exp: now + 7 * 24 * 3600 });
  },

  saveToken(token) {
    return new Promise((resolve) => {
      chrome.storage.local.set({ jwtToken: token }, resolve);
    });
  },

  getToken() {
    return new Promise((resolve) => {
      chrome.storage.local.get("jwtToken", (data) => resolve(data.jwtToken || null));
    });
  },

  removeToken() {
    return new Promise((resolve) => {
      chrome.storage.local.remove("jwtToken", resolve);
    });
  },

  async isAuthenticated() {
    const token = await this.getToken();
    if (!token) return false;
    return this.verify(token) !== null;
  }
};
