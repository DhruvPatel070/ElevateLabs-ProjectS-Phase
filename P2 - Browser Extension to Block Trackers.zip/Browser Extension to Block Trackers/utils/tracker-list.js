/**
 * Privacy Shield - Combined Tracker Domain List
 * All known tracking domains organized by category
 */

const TRACKER_DOMAINS = {
  analytics: [
    "google-analytics.com",
    "googletagmanager.com",
    "hotjar.com",
    "mixpanel.com",
    "segment.io",
    "segment.com",
    "amplitude.com",
    "heapanalytics.com",
    "fullstory.com",
    "mouseflow.com",
    "crazyegg.com",
    "clicktale.net",
    "quantserve.com",
    "scorecardresearch.com",
    "chartbeat.com",
    "optimizely.com",
    "newrelic.com",
    "nr-data.net",
    "matomo.cloud",
    "plausible.io",
    "clarity.ms",
    "luckyorange.com",
    "inspectlet.com",
    "statcounter.com",
    "histats.com",
    "yandex.ru",
    "mc.yandex.ru",
    "clicky.com",
    "woopra.com",
    "kissmetrics.com",
    "intercom.io",
    "intercom.com",
    "drift.com",
    "driftt.com"
  ],
  advertising: [
    "doubleclick.net",
    "googlesyndication.com",
    "googleadservices.com",
    "facebook.net",
    "adnxs.com",
    "adsrvr.org",
    "rubiconproject.com",
    "pubmatic.com",
    "openx.net",
    "casalemedia.com",
    "criteo.com",
    "criteo.net",
    "outbrain.com",
    "taboola.com",
    "amazon-adsystem.com",
    "moatads.com",
    "serving-sys.com",
    "adform.net",
    "bidswitch.net",
    "contextweb.com",
    "indexexchange.com",
    "smartadserver.com",
    "advertising.com",
    "adroll.com",
    "mediavine.com",
    "sharethrough.com",
    "tapad.com",
    "teads.tv",
    "33across.com",
    "appnexus.com",
    "lijit.com",
    "sovrn.com"
  ],
  social: [
    "connect.facebook.net",
    "platform.twitter.com",
    "platform.linkedin.com",
    "apis.google.com",
    "plus.google.com",
    "pinterest.com",
    "snap.licdn.com",
    "static.ads-twitter.com",
    "analytics.tiktok.com",
    "reddit.com",
    "sharethis.com",
    "addthis.com",
    "addtoany.com",
    "disqus.com",
    "sumo.com",
    "twitter.com",
    "linkedin.com"
  ],
  fingerprinting: [
    "fingerprintjs.com",
    "cdn.jsdelivr.net",
    "iovation.com",
    "threatmetrix.com",
    "device-api.urbanairship.com",
    "mpsnare.iesnare.com",
    "cdn.ravenjs.com",
    "maxmind.com",
    "tiqcdn.com",
    "quantcount.com"
  ],
  cryptomining: [
    "coinhive.com",
    "coin-hive.com",
    "jsecoin.com",
    "cryptoloot.pro",
    "minero.cc",
    "authedmine.com",
    "coinimp.com",
    "crypto-loot.com",
    "webminepool.com",
    "hashing.win"
  ]
};

/**
 * Returns a flat array of all tracker domains across all categories.
 * @returns {string[]}
 */
function getAllTrackerDomains() {
  return Object.values(TRACKER_DOMAINS).flat();
}

/**
 * Returns the category for a given domain, or null if not found.
 * @param {string} domain
 * @returns {string|null}
 */
function getCategoryForDomain(domain) {
  const lower = domain.toLowerCase();
  for (const [category, domains] of Object.entries(TRACKER_DOMAINS)) {
    for (const d of domains) {
      if (lower === d || lower.endsWith("." + d)) {
        return category;
      }
    }
  }
  return null;
}

// Export via globalThis for service worker compatibility
globalThis.TRACKER_DOMAINS = TRACKER_DOMAINS;
globalThis.getAllTrackerDomains = getAllTrackerDomains;
globalThis.getCategoryForDomain = getCategoryForDomain;
