/**
 * Privacy Shield – Dashboard Script
 */

const CATEGORIES = ["analytics","advertising","social","fingerprinting","cryptomining"];
const CAT_LABELS = {
  analytics:      "Analytics",
  advertising:    "Advertising",
  social:         "Social",
  fingerprinting: "Fingerprinting",
  cryptomining:   "Cryptomining"
};

function sendMsg(msg) {
  return new Promise((resolve) => chrome.runtime.sendMessage(msg, resolve));
}

function getTodayKey() {
  return new Date().toISOString().slice(0, 10);
}

function getLast14Days() {
  const days = [];
  for (let i = 13; i >= 0; i--) {
    const d = new Date();
    d.setDate(d.getDate() - i);
    days.push(d.toISOString().slice(0, 10));
  }
  return days;
}

// ── Render ────────────────────────────────────────────────────────────────────

function renderOverview(stats) {
  const total   = stats.totalBlocked || 0;
  const today   = (stats.dailyBlocked || {})[getTodayKey()] || 0;
  const unique  = Object.keys(stats.topTrackers || {}).length;
  const days    = Object.values(stats.dailyBlocked || {});
  const avg     = days.length ? Math.round(days.reduce((a, b) => a + b, 0) / days.length) : 0;

  document.getElementById("scTotal").textContent  = total;
  document.getElementById("scToday").textContent  = today;
  document.getElementById("scUnique").textContent = unique;
  document.getElementById("scAvg").textContent    = avg;

  renderBarChart(stats.dailyBlocked || {});
  renderHBars(stats.categoryBreakdown || {}, total);
}

function renderBarChart(dailyBlocked) {
  const days   = getLast14Days();
  const max    = Math.max(1, ...days.map((d) => dailyBlocked[d] || 0));
  const chart  = document.getElementById("barChart");
  chart.innerHTML = days.map((d) => {
    const count  = dailyBlocked[d] || 0;
    const pct    = Math.max(2, Math.round((count / max) * 100));
    const label  = d.slice(5); // MM-DD
    return `
      <div class="bar-col">
        <div class="bar-fill" style="height:${pct}%;" title="${d}: ${count}"></div>
        <div class="bar-label">${label}</div>
      </div>`;
  }).join("");
}

function renderHBars(breakdown, total) {
  const container = document.getElementById("hBars");
  container.innerHTML = CATEGORIES.map((cat) => {
    const count = breakdown[cat] || 0;
    const pct   = total ? Math.round((count / total) * 100) : 0;
    return `
      <div class="h-bar-row">
        <div class="h-bar-label">${CAT_LABELS[cat]}</div>
        <div class="h-bar-track">
          <div class="h-bar-fill fill-${cat}" style="width:${pct}%"></div>
        </div>
        <div class="h-bar-count">${count}</div>
      </div>`;
  }).join("");
}

function renderTopTrackers(topTrackers) {
  const sorted = Object.entries(topTrackers || {})
    .sort(([, a], [, b]) => b - a)
    .slice(0, 30);
  const max = sorted.length ? sorted[0][1] : 1;
  const tbody = document.getElementById("topTrackersBody");
  tbody.innerHTML = sorted.map(([domain, count], i) => {
    const barW = Math.max(2, Math.round((count / max) * 100));
    return `<tr>
      <td class="rank-cell">${i + 1}</td>
      <td class="domain-cell">${escHtml(domain)}</td>
      <td>${count}</td>
      <td><div class="table-bar" style="width:${barW}%"></div></td>
    </tr>`;
  }).join("") || `<tr><td colspan="4" style="text-align:center;color:#555;padding:20px">No data yet</td></tr>`;
}

function renderTimeline(dailyBlocked) {
  const days = getLast14Days().reverse();
  const max  = Math.max(1, ...days.map((d) => dailyBlocked[d] || 0));
  const container = document.getElementById("timelineRows");
  container.innerHTML = days.map((d) => {
    const count = dailyBlocked[d] || 0;
    const pct   = Math.max(2, Math.round((count / max) * 100));
    return `
      <div class="tl-row">
        <div class="tl-date">${d}</div>
        <div class="tl-bar-track">
          <div class="tl-bar-fill" style="width:${pct}%"></div>
        </div>
        <div class="tl-count">${count}</div>
      </div>`;
  }).join("");
}

function renderCategoryDetail(breakdown, total) {
  const grid = document.getElementById("catDetailGrid");
  const COLORS = {
    analytics: "#00d4ff", advertising: "#7b2ff7",
    social: "#ff6b6b",   fingerprinting: "#ffd93d", cryptomining: "#6bcb77"
  };
  grid.innerHTML = CATEGORIES.map((cat) => {
    const count = breakdown[cat] || 0;
    const pct   = total ? ((count / total) * 100).toFixed(1) : "0.0";
    return `
      <div class="cat-detail-card">
        <div class="cdc-title" style="color:${COLORS[cat]}">${CAT_LABELS[cat]}</div>
        <div class="cdc-count">${count}</div>
        <div class="cdc-pct">${pct}% of total</div>
      </div>`;
  }).join("");
}

function escHtml(str) {
  return str.replace(/[&<>"']/g, (c) =>
    ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}

// ── Navigation ────────────────────────────────────────────────────────────────
document.querySelectorAll(".nav-item").forEach((link) => {
  link.addEventListener("click", (e) => {
    e.preventDefault();
    const section = link.dataset.section;
    document.querySelectorAll(".nav-item").forEach((l) => l.classList.remove("active"));
    document.querySelectorAll(".section").forEach((s) => s.classList.remove("active"));
    link.classList.add("active");
    document.getElementById("section-" + section).classList.add("active");
  });
});

// ── Reset / Export ────────────────────────────────────────────────────────────
document.getElementById("btnReset").addEventListener("click", () => {
  if (confirm("Reset all statistics? This cannot be undone.")) {
    sendMsg({ type: "RESET_STATS" }).then(() => loadData());
  }
});

document.getElementById("btnExport").addEventListener("click", async () => {
  const stats = await sendMsg({ type: "GET_GLOBAL_STATS" });
  const blob  = new Blob([JSON.stringify(stats, null, 2)], { type: "application/json" });
  const url   = URL.createObjectURL(blob);
  const a     = document.createElement("a");
  a.href      = url;
  a.download  = `privacy-shield-stats-${getTodayKey()}.json`;
  a.click();
  URL.revokeObjectURL(url);
});

// ── Load ──────────────────────────────────────────────────────────────────────
async function loadData() {
  const stats = await sendMsg({ type: "GET_GLOBAL_STATS" });
  if (!stats) return;
  renderOverview(stats);
  renderTopTrackers(stats.topTrackers);
  renderTimeline(stats.dailyBlocked || {});
  renderCategoryDetail(stats.categoryBreakdown || {}, stats.totalBlocked || 0);
}

loadData();
