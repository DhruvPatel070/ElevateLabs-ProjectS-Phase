/**
 * Privacy Shield – Auth Page Script
 */

// ── Helpers ───────────────────────────────────────────────────────────────────
function showMsg(id, text, type) {
  const el = document.getElementById(id);
  el.textContent = text;
  el.className   = "msg " + type;
  clearTimeout(el._timer);
  el._timer = setTimeout(() => { el.className = "msg hidden"; }, 4000);
}

function showCard(id) {
  ["loginCard","registerCard","profileCard"].forEach((c) => {
    document.getElementById(c).classList.toggle("hidden", c !== id);
  });
}

// ── Navigation ────────────────────────────────────────────────────────────────
document.getElementById("goRegister").addEventListener("click", (e) => { e.preventDefault(); showCard("registerCard"); });
document.getElementById("goLogin").addEventListener("click",    (e) => { e.preventDefault(); showCard("loginCard"); });

// ── Sign In ───────────────────────────────────────────────────────────────────
document.getElementById("btnSignIn").addEventListener("click", async () => {
  const username = document.getElementById("loginUsername").value.trim();
  const password = document.getElementById("loginPassword").value;

  if (!username || !password) return showMsg("loginMsg", "Please fill in all fields.", "error");

  chrome.storage.local.get("users", async (data) => {
    const users = data.users || {};
    const user  = users[username];
    if (!user) return showMsg("loginMsg", "Invalid username or password.", "error");

    // Verify password: hash with stored salt and compare
    const hashed = await JWTAuth.hashPassword(password, user.salt || "");
    if (hashed !== user.passwordHash) {
      return showMsg("loginMsg", "Invalid username or password.", "error");
    }
    const token = JWTAuth.generateToken(username);
    await JWTAuth.saveToken(token);
    showMsg("loginMsg", "Signed in!", "success");
    setTimeout(() => {
      document.getElementById("profileUser").textContent = username;
      showCard("profileCard");
    }, 800);
  });
});

// ── Register ──────────────────────────────────────────────────────────────────
document.getElementById("btnRegister").addEventListener("click", async () => {
  const username = document.getElementById("regUsername").value.trim();
  const password = document.getElementById("regPassword").value;
  const confirm  = document.getElementById("regConfirm").value;

  if (!username || !password || !confirm) return showMsg("registerMsg", "Please fill in all fields.", "error");
  if (password.length < 6)  return showMsg("registerMsg", "Password must be at least 6 characters.", "error");
  if (password !== confirm)  return showMsg("registerMsg", "Passwords do not match.", "error");

  chrome.storage.local.get("users", async (data) => {
    const users = data.users || {};
    if (users[username]) return showMsg("registerMsg", "Username already taken.", "error");

    // Hash password with a random salt using SHA-256
    const salt         = JWTAuth.generateSalt();
    const passwordHash = await JWTAuth.hashPassword(password, salt);
    users[username]    = { passwordHash, salt };

    chrome.storage.local.set({ users }, async () => {
      const token = JWTAuth.generateToken(username);
      await JWTAuth.saveToken(token);
      showMsg("registerMsg", "Account created!", "success");
      setTimeout(() => {
        document.getElementById("profileUser").textContent = username;
        showCard("profileCard");
      }, 800);
    });
  });
});

// ── Sign Out ──────────────────────────────────────────────────────────────────
document.getElementById("btnSignOut").addEventListener("click", async () => {
  await JWTAuth.removeToken();
  showCard("loginCard");
});

// ── Init: check if already logged in ─────────────────────────────────────────
(async () => {
  const isAuth = await JWTAuth.isAuthenticated();
  if (isAuth) {
    const token = await JWTAuth.getToken();
    const payload = JWTAuth.verify(token);
    document.getElementById("profileUser").textContent = payload ? payload.sub : "user";
    showCard("profileCard");
  }
})();
