/**
 * Privacy Shield – Options / Settings Script
 */

const DOMAIN_RE = /^([a-z0-9-]+\.)+[a-z]{2,}$/;

let whitelist = [];
let blacklist = [];

function sendMsg(msg) {
  return new Promise((resolve) => chrome.runtime.sendMessage(msg, resolve));
}

function showStatus(msg, type) {
  const el = document.getElementById("statusMsg");
  el.textContent = msg;
  el.className   = "status-msg " + type;
  clearTimeout(el._timer);
  el._timer = setTimeout(() => { el.className = "status-msg hidden"; }, 3000);
}

// ── Render lists ─────────────────────────────────────────────────────────────
function renderList(listId, items, removeFn) {
  const ul = document.getElementById(listId);
  ul.innerHTML = items.length
    ? items.map((d) => `
        <li class="domain-item">
          <span>${escHtml(d)}</span>
          <button class="remove-btn" data-domain="${escHtml(d)}" title="Remove">✕</button>
        </li>`).join("")
    : '<li style="color:#555;font-size:11px;padding:8px">No domains added</li>';
  ul.querySelectorAll(".remove-btn").forEach((btn) => {
    btn.addEventListener("click", () => removeFn(btn.dataset.domain));
  });
}

function escHtml(str) {
  return String(str).replace(/[&<>"']/g, (c) =>
    ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}

function refresh() {
  renderList("whitelistItems", whitelist, removeFromWhitelist);
  renderList("blacklistItems", blacklist, removeFromBlacklist);
}

// ── Whitelist ─────────────────────────────────────────────────────────────────
async function addToWhitelist() {
  const input = document.getElementById("whitelistInput");
  const domain = input.value.trim().toLowerCase();
  if (!DOMAIN_RE.test(domain)) return showStatus("Invalid domain format.", "error");
  if (whitelist.includes(domain)) return showStatus("Domain already in whitelist.", "error");
  whitelist.push(domain);
  input.value = "";
  await sendMsg({ type: "UPDATE_WHITELIST", whitelist });
  refresh();
  showStatus("Added to whitelist.", "success");
}

async function removeFromWhitelist(domain) {
  whitelist = whitelist.filter((d) => d !== domain);
  await sendMsg({ type: "UPDATE_WHITELIST", whitelist });
  refresh();
  showStatus("Removed from whitelist.", "success");
}

// ── Blacklist ─────────────────────────────────────────────────────────────────
async function addToBlacklist() {
  const input = document.getElementById("blacklistInput");
  const domain = input.value.trim().toLowerCase();
  if (!DOMAIN_RE.test(domain)) return showStatus("Invalid domain format.", "error");
  if (blacklist.includes(domain)) return showStatus("Domain already in blacklist.", "error");
  blacklist.push(domain);
  input.value = "";
  await sendMsg({ type: "UPDATE_BLACKLIST", blacklist });
  refresh();
  showStatus("Added to blacklist.", "success");
}

async function removeFromBlacklist(domain) {
  blacklist = blacklist.filter((d) => d !== domain);
  await sendMsg({ type: "UPDATE_BLACKLIST", blacklist });
  refresh();
  showStatus("Removed from blacklist.", "success");
}

// ── Export ────────────────────────────────────────────────────────────────────
document.getElementById("btnExport").addEventListener("click", () => {
  const blob = new Blob([JSON.stringify({ whitelist, blacklist }, null, 2)], { type: "application/json" });
  const url  = URL.createObjectURL(blob);
  const a    = document.createElement("a");
  a.href = url; a.download = "privacy-shield-lists.json"; a.click();
  URL.revokeObjectURL(url);
  showStatus("Lists exported.", "success");
});

// ── Import ────────────────────────────────────────────────────────────────────
document.getElementById("importFile").addEventListener("change", async (e) => {
  const file = e.target.files[0];
  if (!file) return;
  try {
    const text = await file.text();
    const data = JSON.parse(text);
    if (!Array.isArray(data.whitelist) || !Array.isArray(data.blacklist)) throw new Error("bad format");
    whitelist = data.whitelist.filter((d) => DOMAIN_RE.test(d));
    blacklist = data.blacklist.filter((d) => DOMAIN_RE.test(d));
    await sendMsg({ type: "UPDATE_WHITELIST", whitelist });
    await sendMsg({ type: "UPDATE_BLACKLIST", blacklist });
    refresh();
    showStatus("Lists imported successfully.", "success");
  } catch (_) {
    showStatus("Import failed: invalid JSON.", "error");
  }
  e.target.value = "";
});

// ── Button listeners ──────────────────────────────────────────────────────────
document.getElementById("btnAddWhitelist").addEventListener("click", addToWhitelist);
document.getElementById("whitelistInput").addEventListener("keypress", (e) => {
  if (e.key === "Enter") addToWhitelist();
});

document.getElementById("btnAddBlacklist").addEventListener("click", addToBlacklist);
document.getElementById("blacklistInput").addEventListener("keypress", (e) => {
  if (e.key === "Enter") addToBlacklist();
});

// ── Init ──────────────────────────────────────────────────────────────────────
async function init() {
  const [wl, bl] = await Promise.all([
    sendMsg({ type: "GET_WHITELIST" }),
    sendMsg({ type: "GET_BLACKLIST" })
  ]);
  whitelist = wl ? wl.whitelist : [];
  blacklist = bl ? bl.blacklist : [];
  refresh();
}

init();
