/**
 * Privacy Shield - Popup Script
 */

const $ = (id) => document.getElementById(id);

async function getCurrentTab() {
  return new Promise((resolve) => {
    chrome.tabs.query({ active: true, currentWindow: true }, ([tab]) => resolve(tab));
  });
}

function sendMsg(msg) {
  return new Promise((resolve) => chrome.runtime.sendMessage(msg, resolve));
}

// ── Category colours (matching CSS) ─────────────────────────────────────────
const CAT_LABEL = {
  analytics:      "Analytics",
  advertising:    "Advertising",
  social:         "Social",
  fingerprinting: "Fingerprint",
  cryptomining:   "Cryptomining"
};

function renderTrackerList(details) {
  const list = $("trackerList");
  if (!details || details.length === 0) {
    list.innerHTML = '<div class="empty-msg">No trackers blocked yet on this page.</div>';
    return;
  }
  list.innerHTML = details.map((item) => `
    <div class="tracker-row">
      <span class="tracker-domain">${item.domain || "unknown"}</span>
      <span class="badge badge-${item.category || "unknown"}">${CAT_LABEL[item.category] || item.category || "unknown"}</span>
    </div>
  `).join("");
}

function getTodayKey() {
  return new Date().toISOString().slice(0, 10);
}

async function init() {
  // Master toggle state
  chrome.storage.local.get("extensionEnabled", (data) => {
    $("masterToggle").checked = data.extensionEnabled !== false;
  });

  // Current tab stats
  const tab = await getCurrentTab();
  if (tab) {
    const stats = await sendMsg({ type: "GET_TAB_STATS", tabId: tab.id });
    $("tabCount").textContent = stats ? stats.count : 0;
    renderTrackerList(stats ? stats.details : []);
  }

  // Global stats
  const global = await sendMsg({ type: "GET_GLOBAL_STATS" });
  if (global) {
    $("totalAll").textContent  = global.totalBlocked || 0;
    $("todayCount").textContent = (global.dailyBlocked || {})[getTodayKey()] || 0;

    const breakdown = global.categoryBreakdown || {};
    ["analytics","advertising","social","fingerprinting","cryptomining"].forEach((cat) => {
      const el = $("cat-" + cat);
      if (el) el.textContent = breakdown[cat] || 0;
    });
  }
}

// ── Events ───────────────────────────────────────────────────────────────────
$("masterToggle").addEventListener("change", (e) => {
  sendMsg({ type: "TOGGLE_EXTENSION", enabled: e.target.checked });
});

$("btnDashboard").addEventListener("click", () => {
  chrome.tabs.create({ url: chrome.runtime.getURL("dashboard/dashboard.html") });
  window.close();
});

$("btnOptions").addEventListener("click", () => {
  chrome.runtime.openOptionsPage();
  window.close();
});

$("authLink").addEventListener("click", (e) => {
  e.preventDefault();
  chrome.tabs.create({ url: chrome.runtime.getURL("auth/auth.html") });
  window.close();
});

init();
