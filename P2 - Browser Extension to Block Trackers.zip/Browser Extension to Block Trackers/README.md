# 🛡️ Privacy Shield – Tracker Blocker Browser Extension

A complete, standalone privacy-focused browser extension built with **Manifest V3**, plain **HTML/CSS/JS** (no frameworks), that blocks known tracking scripts and works on **Chrome, Firefox, Brave, and Edge**.

## ✨ Features

- 🚫 **Block 100+ Trackers** – analytics, advertising, social, fingerprinting, and cryptomining domains
- 📊 **Real-time Analytics Dashboard** – timeline, top trackers, category breakdown, export as JSON
- 🔢 **Badge Counter** – toolbar badge shows trackers blocked on the current page
- ⚙️ **Whitelist / Blacklist** – allow trusted sites or add custom block rules
- 🔑 **JWT Authentication** – optional user accounts stored in local storage
- 🌐 **Multi-Browser** – Chrome, Firefox, Brave, Edge via Manifest V3

## 🛠️ Tech Stack

| Area | Tech |
|------|------|
| Extension API | Manifest V3, `declarativeNetRequest`, `webNavigation` |
| Frontend | Plain HTML5 + CSS3 + vanilla JavaScript |
| Auth | Client-side JWT (no external dependencies) |
| Storage | `chrome.storage.local` |

## 📁 Project Structure

```
├── manifest.json            # MV3 extension config
├── background.js            # Service worker – blocking logic & state
├── content.js               # Content script – DOM mutation observer
├── rules/
│   └── tracker_rules.json   # Declarative Net Request block rules (25+)
├── popup/
│   ├── popup.html/css/js    # Extension popup (380×500 dark UI)
├── dashboard/
│   ├── dashboard.html/css/js # Full analytics dashboard
├── options/
│   ├── options.html/css/js  # Whitelist / Blacklist settings
├── auth/
│   ├── auth.html/css/js     # Login / Register / Profile
├── utils/
│   ├── jwt.js               # JWT sign / verify / store
│   └── tracker-list.js      # 100+ tracker domains by category
├── icons/                   # 16, 48, 128 px extension icons
└── install/
    └── install.html         # Download & install guide page
```

## 🚀 Installation

### Chrome, Brave, or Edge
1. Download / clone this repository
2. Open **`chrome://extensions`** (or `brave://extensions` / `edge://extensions`)
3. Enable **Developer mode** (top-right toggle)
4. Click **"Load unpacked"** and select the repository folder
5. The 🛡️ icon appears in your toolbar — done!

### Firefox
1. Open **`about:debugging#/runtime/this-firefox`**
2. Click **"Load Temporary Add-on…"**
3. Select the `manifest.json` file inside the repository folder

## 🗂️ Tracker Categories

| Category | Domains | Examples |
|----------|---------|---------|
| Analytics | 34+ | Google Analytics, Hotjar, Mixpanel, Amplitude |
| Advertising | 32+ | DoubleClick, AdNXS, Criteo, Taboola |
| Social | 17+ | Facebook, Twitter, LinkedIn widgets |
| Fingerprinting | 10+ | FingerprintJS, MaxMind, ThreatMetrix |
| Cryptomining | 10+ | CoinHive, CryptoLoot, JSECoin |

## ⚙️ How It Works

1. **Declarative Net Request** rules block the top 25 trackers at the network level before they load
2. The **background service worker** tracks blocked requests per-tab and globally
3. The **content script** uses a `MutationObserver` to catch dynamically injected tracking scripts
4. The **popup** displays real-time per-page and all-time stats
5. The **dashboard** provides a full analytics view with CSS-only charts

## 📄 License

MIT License – feel free to use, modify, and distribute.
